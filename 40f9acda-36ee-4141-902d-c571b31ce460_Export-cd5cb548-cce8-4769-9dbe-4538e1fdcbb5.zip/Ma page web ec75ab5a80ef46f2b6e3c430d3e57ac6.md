# Ma page web

# 🗺️Plan du site

---

[RECETTES DE CUISINE](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/RECETTES%20DE%20CUISINE%2037740b86c7e34d60b5e89fff12fa5dd0.csv)

![recette de cuisine.jpg](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/42a37dd1-8436-48c6-aa65-348ebd537d74.png)

[RECETTES DE COCKTAIL](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/RECETTES%20DE%20COCKTAIL%204ecfad96aae14498a24f1789661ddfa9.csv)

![https://images.unsplash.com/photo-1574879948818-1cfda7aa5b1a?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1574879948818-1cfda7aa5b1a?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[ACTIVITES](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/ACTIVITES%20c8cb6dcb42f845f085723c6963a33cf5.csv)

![https://images.unsplash.com/photo-1524006231331-78f794ebbbac?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1524006231331-78f794ebbbac?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[MUSIQUE ET PLAYLIST](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/MUSIQUE%20ET%20PLAYLIST%200dba1b0c9c3243928e87b6a6dda313d2.csv)

![https://images.unsplash.com/photo-1626539896924-b328af4ef01d?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1626539896924-b328af4ef01d?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[Soirée en famille](https://www.notion.so/Soir-e-en-famille-fdb58cf5bc4f4b2982a627d86de4809f?pvs=21)

![https://images.unsplash.com/photo-1517457373958-b7bdd4587205?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1517457373958-b7bdd4587205?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

---

# 🎁Ressources partagées

> Vivre sainement
> 

---

CUISINE

COCKTAIL

ACTIVITES

MUSIQUE

---

# 🎉Evènements

---

[INVITATION AU VOYAGE](Ma%20page%20web%20ec75ab5a80ef46f2b6e3c430d3e57ac6/INVITATION%20AU%20VOYAGE%20fb93fdebdd0b411bbb65d66baa4521ce.csv)

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)

<aside>
💡 Faites une page web

</aside>